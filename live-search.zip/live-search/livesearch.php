<?php

$conn = mysql_connect("localhost","root","");
$db = mysql_select_db("test",$conn);
//get the q parameter from URL
$q=$_GET["q"];

$result = mysql_query("select * from table1 where name like '%$q%' " );

while($row = mysql_fetch_assoc($result))
      {
	  echo "<li><a>" .$row['name'] ."</a></li>";
	  echo "<br>";
	  
	  }


?>